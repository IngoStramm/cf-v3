=== Plugin Name ===
Requires at least: 4.7
Tested up to: 5.5
Stable tag: 4.3
Requires PHP: 7.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Este plugin é parte integrante do ConverteFácil.

== Description ==

Este plugin foi desenvolvido para ser usado em conjunto com o <a href="https://convertefacil.com.br">Converte Fácil</a>. Ele não deve ser usado fora do ambiente de instalação do <strong>Converte Fácil</strong>.

Caso algum erro surja em decorrência do uso plugin, a <a href="https://agencialaf.com">Agência LAF</a> deve ser procurada para providenciar o suporte adequado.