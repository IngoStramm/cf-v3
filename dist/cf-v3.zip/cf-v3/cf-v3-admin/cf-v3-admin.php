<?php

require_once 'cf-v3-admin-scheme-color.php';
require_once 'cf-v3-admin-style.php';
require_once 'cf-v3-admin-dashboard.php';
require_once 'cf-v3-admin-notices.php';
require_once 'cf-v3-admin-menu.php';
require_once 'cf-v3-admin-bar.php';
require_once 'cf-v3-admin-login.php';
